pdf('Analysis of Sales Report of a Clothes Manufacturing Outlet.pdf')

#Load And Understand Dataset
#install.packages("readxl")
library(readxl)
library(dplyr)

#Load Attribute dataset        
attribute = read_excel('D:/elective 2/project/project1/1555052405_datasets/Attribute DataSet.xlsx')
View(attribute)
dim(attribute) 
names(attribute)
str(attribute) 


# return list of unique values in each row
lapply(attribute[1:13], unique)

#Eliminate duplicate values       
attribute$Style[attribute$Style == 'sexy'] = 'Sexy'

attribute$Price[attribute$Price == 'low'] = 'Low'
attribute$Price[attribute$Price == 'high'] = 'High'
       
attribute$Size[attribute$Size == 's'] = 'Small' 
attribute$Size[attribute$Size == 'small'] = 'Small'
attribute$Size[attribute$Size == 'S'] = 'Small'

attribute$Season[attribute$Season == 'spring'] = 'Spring'
attribute$Season[attribute$Season == 'summer'] = 'Summer'
attribute$Season[attribute$Season == 'Automn'] = 'Autumn'
attribute$Season[attribute$Season == 'winter'] = 'Winter'
       
attribute$NeckLine[attribute$NeckLine == 'sweetheart'] = 'Sweetheart'
       
attribute$SleeveLength[attribute$SleeveLength == 'sleevless'] = 'sleeveless' 
attribute$SleeveLength[attribute$SleeveLength == 'sleeevless'] = 'sleeveless' 
attribute$SleeveLength[attribute$SleeveLength == 'sleveless'] = 'sleeveless' 
attribute$SleeveLength[attribute$SleeveLength == 'threequater'] = 'threequarter'
attribute$SleeveLength[attribute$SleeveLength == 'thressqatar'] = 'threequarter'
attribute$SleeveLength[attribute$SleeveLength == 'urndowncollor'] = 'turndowncollar' 
attribute$SleeveLength[attribute$SleeveLength == 'capsleeves'] = 'cap-sleeves'

attribute$Material[attribute$Material == 'sill'] = 'silk'

attribute$FabricType[attribute$FabricType == 'shiffon'] = 'chiffon'
attribute$FabricType[attribute$FabricType == 'sattin'] = 'satin'
attribute$FabricType[attribute$FabricType == 'wollen'] = 'woolen'
attribute$FabricType[attribute$FabricType == 'flannael'] = 'flannel'
attribute$FabricType[attribute$FabricType == 'knitting'] = 'knitted'
       
attribute$Decoration[attribute$Decoration == 'embroidary'] = 'embroidery'
attribute$Decoration[attribute$Decoration == 'sequined'] = 'sequins'
attribute$Decoration[attribute$Decoration == 'ruched'] = 'ruche'
attribute$Decoration[attribute$Decoration == 'none'] = 'null'
       
attribute$'Pattern Type'[attribute$'Pattern Type' == 'none'] = 'null' 
attribute$'Pattern Type'[attribute$'Pattern Type' == 'leapord'] = 'leopard'

#checking if any duplicate remain
lapply(attribute[1:13], unique)

#Convert character value into factor    
attribute$Style = factor(attribute$Style,
                         levels = c('Sexy','Casual','vintage','Brief','cute','bohemian','Novelty','Flare','party','work','OL','fashion'),
                         labels = c(0,1,2,3,4,5,6,7,8,9,10,11))

attribute$Price = factor(attribute$Price,
                         levels = c('Low','High','Average','Medium','very-high'),
                         labels = c(0,1,2,3,4))
        
attribute$Size = factor(attribute$Size,
                        levels = c('M','L','XL','free','Small'),
                        labels = c(0,1,2,3,4))

attribute$Season = factor(attribute$Season,
                          levels = c('Summer','Autumn','Spring','Winter'),
                          labels = c(0,1,2,3))

attribute$NeckLine = factor(attribute$NeckLine,
                            levels = c('o-neck','v-neck','boat-neck','peterpan-collor','ruffled','turndowncollor','slash-neck','mandarin-collor','open','sqare-collor','Sweetheart','Scoop','halter','backless','bowneck','NULL'),
                            labels = c(0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15))

attribute$SleeveLength = factor(attribute$SleeveLength,
                                levels = c('sleeveless','Petal','full','butterfly','short','threequarter','halfsleeve','cap-sleeves','turndowncollor','half','turndowncollar','NULL'),
                                labels = c(0,1,2,3,4,5,6,7,8,9,10,11))
        
attribute$waiseline = factor(attribute$waiseline,
                             levels = c('empire','natural','null','princess','dropped'),
                             labels = c(0,1,2,3,4))
        
attribute$Material = factor(attribute$Material,
                            levels = c('null','microfiber','polyster','silk','chiffonfabric','cotton','nylon','other','milksilk','linen','rayon','lycra','mix','acrylic','spandex','lace','modal','cashmere','viscos','knitting','wool','model','shiffon'),
                            labels = c(0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22))
        
attribute$FabricType = factor(attribute$FabricType,
                              levels = c('chiffon','null','broadcloth','jersey','other','batik','satin','flannel','worsted','woolen','poplin','dobby','knitted','tulle','organza','lace','Corduroy','terry'),
                              labels = c(0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17))
        
attribute$Decoration = factor(attribute$Decoration,
                              levels = c('ruffles','null','embroidery','bow','lace','beading','sashes','hollowout','pockets','sequins','applique','button','Tiered','rivet','feathers','flowers','pearls','pleat','crystal','ruche','draped','tassel','plain','cascading'),
                              labels = c(0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23))
        
attribute$`Pattern Type` = factor(attribute$`Pattern Type`,
                                  levels = c('animal','print','dot','solid','null','patchwork','striped','geometric','plaid','leopard','floral','character','splice'),
                                  labels = c(0,1,2,3,4,5,6,7,8,9,10,11,12))

library(plyr)        
attribute$Recommendation = sapply(attribute$Recommendation, factor)
summary(attribute)

#check if any null value is present     
colSums(is.na(attribute))

#fill null values with mode by making made function
mode<-function(mode){
  unique=unique(mode)
  unique[which.max(tabulate(match(mode,unique)))]
}

attribute$Price=mode(attribute$Price)
attribute$Season=mode(attribute$Season)
attribute$NeckLine=mode(attribute$NeckLine)
attribute$waiseline=mode(attribute$waiseline)
attribute$Material=mode(attribute$Material)
attribute$FabricType=mode(attribute$FabricType)
attribute$Decoration=mode(attribute$Decoration)
attribute$`Pattern Type`=mode(attribute$`Pattern Type`)

#checking if any column still have any null value
colSums(is.na(attribute))

#Load Dresssale dataset
dresssale = read_excel('D:/elective 2/project/project1/1555052405_datasets/Dress Sales.xlsx')
View(dresssale) 
dim(dresssale) 
str(dresssale) 
summary(dresssale)

#checking if any duplicate column present
anyDuplicated(colnames(dresssale))

#select the range of columns that are important 
dresssale= dresssale[2:24]     

#remane column name that are incorrect
colnames(dresssale)[colnames(dresssale) == "41314"] <- "02/9/2013"
colnames(dresssale)[colnames(dresssale) == "41373"] <- "04/9/2013"
colnames(dresssale)[colnames(dresssale) == "41434"] <- "06/9/2013"
colnames(dresssale)[colnames(dresssale) == "41495"] <- "08/9/2013"
colnames(dresssale)[colnames(dresssale) == "41556"] <- "10/9/2013"
colnames(dresssale)[colnames(dresssale) == "41617"] <- "12/9/2013"
colnames(dresssale)[colnames(dresssale) == "41315"] <- "02/10/2013"
colnames(dresssale)[colnames(dresssale) == "41374"] <- "04/10/2013"
colnames(dresssale)[colnames(dresssale) == "41435"] <- "06/10/2013"
colnames(dresssale)[colnames(dresssale) == "40400"] <- "08/10/2013"
colnames(dresssale)[colnames(dresssale) == "41557"] <- "10/10/2013"
colnames(dresssale)[colnames(dresssale) == "41618"] <- "12/10/2013"

#checking all columns names
colnames(dresssale)

#convert dataset into dataframe
dresssale=data.frame(dresssale)
View(dresssale)

#convert values into numeric
dresssale$X12.9.2013=as.numeric(dresssale$X12.9.2013)
dresssale$X14.9.2013=as.numeric(dresssale$X14.9.2013)
dresssale$X16.9.2013=as.numeric(dresssale$X16.9.2013)
dresssale$X18.9.2013=as.numeric(dresssale$X18.9.2013)
dresssale$X20.9.2013=as.numeric(dresssale$X20.9.2013)
dresssale$X22.9.2013=as.numeric(dresssale$X22.9.2013)

#checking if there any null value
colSums(is.na(dresssale))

#fill null values with mean value
dresssale$X12.9.2013=mean(dresssale$X12.9.2013, na.rm=TRUE)
dresssale$X14.9.2013=mean(dresssale$X14.9.2013, na.rm=TRUE)
dresssale$X16.9.2013=mean(dresssale$X16.9.2013, na.rm=TRUE)
dresssale$X18.9.2013=mean(dresssale$X18.9.2013, na.rm=TRUE)
dresssale$X20.9.2013=mean(dresssale$X20.9.2013, na.rm=TRUE)
dresssale$X22.9.2013=mean(dresssale$X22.9.2013, na.rm=TRUE)
dresssale$X26.9.2013=mean(dresssale$X26.9.2013, na.rm=TRUE)
dresssale$X30.9.2013=mean(dresssale$X30.9.2013, na.rm=TRUE)
dresssale$X02.10.2013=mean(dresssale$X02.10.2013, na.rm=TRUE)
dresssale$X04.10.2013=mean(dresssale$X04.10.2013, na.rm=TRUE)
dresssale$X08.10.2013=mean(dresssale$X08.10.2013, na.rm=TRUE)
dresssale$X10.10.2013=mean(dresssale$X10.10.2013, na.rm=TRUE)

#add new column totalsales that is the sums of all values in each column
dresssale$totalsales=rowSums(dresssale)
head(dresssale)

#fetch only totalsales column
dresssale<-dresssale$totalsales
View(dresssale)

#merge attribute and dressale table together
merge<-merge.data.frame(attribute,dresssale)
View(merge)

#rename column into totalsales
colnames(merge)[colnames(merge) == "y"] <- "totalsales"
merge$totalsales = sapply(merge$totalsales, factor)
merge$Rating = sapply(merge$Rating, factor)
colnames(merge)
str(merge)

#plot graph and chart
boxplot(merge$totalsales ~ merge$Style, data = merge)
boxplot(merge$totalsales ~ merge$Price, data = merge)
boxplot(merge$totalsales ~ merge$Rating, data = merge)

pairs(~totalsales + Style + Price + Rating, data = merge)


#split data into training and testing data
#install.packages("caTools")
library(caTools)

set.seed(100)

split_data = sample.split(merge$Recommendation, SplitRatio = 0.7)
training_set = subset(merge, split_data==TRUE)
testing_set = subset(merge, split_data==FALSE)

dim(training_set)
dim(testing_set)

#load support vector machine and predict
library(e1071)
library(caret)
library(ggplot2)
library(lattice)

#finding svm algorithm prediction
svm<-svm(Recommendation~.,training_set)
conmatrix<-confusionMatrix(training_set$Recommendation , predict(svm) , positive='1')
print(conmatrix)
prediction<-predict(svm,testing_set)
pred<-(table(pred=prediction,true=testing_set[,1]))
print(pred)
plot(prediction)

#naive Bayes algorithm
#install.packages("mlbench")
#library(mlbench)
naive_model<-naiveBayes(Recommendation~.,data=training_set)
print(naive_model)
naive_predict<-predict(naive_model,testing_set)
table(pred=naive_predict,true=testing_set[,1])
plot(naive_predict)

#Decision Tree algorithm
#install.packages('rpart')
library(rpart)
tree_model<-rpart(Recommendation~.,data=training_set,method='class')
printcp(tree_model)
plot(tree_model)
summary(tree_model)
tree_predict<-predict(tree_model,testing_set)
plot(tree_predict)

dev.off()

